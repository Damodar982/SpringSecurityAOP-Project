package com.gl.aopsample.springsecurityaop.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Employee {

	@Id
	private int id;
	
	@Column 
	private String employeeName;
	
	@Column
	private String employeeAddress;
}
