package com.gl.aopsample.springsecurityaop.config;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.gl.aopsample.springsecurityaop.entity.Employee;
import com.gl.aopsample.springsecurityaop.service.EmployeeServiceImpl;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Aspect
@Slf4j
public class AspectConfig {
	
	@Autowired
	EmployeeServiceImpl employeeService;

	//PointCut expr: accessModifier returnType packageName.className.methodName(..)
	@Before("execution(public * com.gl.aop.aopsample.service.*.*(..))")
	public void logBeforeAllMethods(JoinPoint joinPoint)
	{
		log.info(joinPoint.getSignature().getName()+ " Started ..");
	}
	@After("execution(public * com.gl.aop.aopsample.service.*.*(..))")
	public void logAfterAllMethods(JoinPoint joinPoint)
	{
		log.info(joinPoint.getSignature().getName()+ " Completed ..");
	}
	
	@Around("execution(public * com.gl.aop.aopsample.service.CustomerServiceImpl.*(..))")
	public void logBeforeAndAfterAllMethods(ProceedingJoinPoint proceedingJoinPoint) 
	{
		log.info(proceedingJoinPoint.getSignature().getName()+"  Started");
		try {
			proceedingJoinPoint.proceed();

		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.info(proceedingJoinPoint.getSignature().getName()+"  Completed");
	} 
		
	@AfterReturning("execution(public * com.gl.aop.aopsample.service.CustomerServiceImpl.*(..))")
	public void logAfterAllMethods1(JoinPoint joinPoint)
	{
		log.info(joinPoint.getSignature().getName()+ " Completed Successfully..");
	}
	
	@AfterThrowing("execution(public * com.gl.aop.aopsample.service.EmployeeServiceImpl.updateEmployee(..))")
	public void logAfterExceptionForUpdation(JoinPoint joinPoint)
	{
		Employee employee = (Employee)joinPoint.getArgs()[0];
		log.info(employee +"Does not exist Updation Failed");
		
	} /**/
}
