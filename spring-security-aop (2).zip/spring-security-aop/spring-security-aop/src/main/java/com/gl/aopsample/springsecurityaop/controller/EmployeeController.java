package com.gl.aopsample.springsecurityaop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gl.aopsample.springsecurityaop.entity.Employee;
import com.gl.aopsample.springsecurityaop.service.CustomerServiceImpl;
import com.gl.aopsample.springsecurityaop.service.EmployeeServiceImpl;

@RestController
@RequestMapping("/")
public class EmployeeController {

	@Autowired
	EmployeeServiceImpl employeeService;
	
	@Autowired
	CustomerServiceImpl customerService;
	
	@GetMapping("/employees")
	public List<Employee> getAllEmployees()
	{
		return employeeService.getAllEmployees();
	}
	
	@PostMapping("/employees")
	public void saveEmployee(@RequestBody Employee employee)
	{
		employeeService.saveEmployee(employee);
	}
	
	@GetMapping("/employees/{eid}")
	public Employee getEmployeeById(@PathVariable int eid)
	{
		return employeeService.getEmployeeById(eid);
	}
	
	@PutMapping("/employees")
	public void updateEmployee(@RequestBody Employee employee)
	{
		employeeService.updateEmployee(employee);
	}
	@DeleteMapping("/employees/{eid}")
	public void deleteEmployeeById(@PathVariable int eid)
	{
		employeeService.deleteEmployeeById(eid);
	}
}
