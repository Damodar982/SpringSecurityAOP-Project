package com.gl.aopsample.springsecurityaop.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gl.aopsample.springsecurityaop.entity.Employee;
import com.gl.aopsample.springsecurityaop.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl {

	@Autowired
	EmployeeRepository employeeRepo;
	
	public List<Employee> getAllEmployees()
	{
		return employeeRepo.findAll();
	}
	
	public void saveEmployee(Employee employee)
	{
		employeeRepo.save(employee);
	}
	
	public Employee getEmployeeById(int empId)
	{
		Optional<Employee> employee=employeeRepo.findById(empId);
		return employee.get();
	}
	public void deleteEmployeeById(int empId)
	{
		employeeRepo.deleteById(empId);
	}
	
	public void updateEmployee(Employee employee)
	{
		boolean exists=employeeRepo.existsById(employee.getId());
		if(exists)
		{
			employeeRepo.saveAndFlush(employee);
		}
		else
		{
			throw new RuntimeException("Employee does not exist for id "+employee.getId());
		}
	}
}
