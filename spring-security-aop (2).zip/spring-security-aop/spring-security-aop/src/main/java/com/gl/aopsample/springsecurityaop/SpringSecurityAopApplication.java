package com.gl.aopsample.springsecurityaop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication
/*
Spring Boot provides @SpringBootApplication annotation as a short-cut for:
@Configuration
@ComponentScan
@EnableAutoConfgiuration
 */
public class SpringSecurityAopApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityAopApplication.class, args);
		//new SpringApplicationBuilder(SpringSecurityAopApplication.class)
        //.web(WebApplicationType.NONE)
        //.run(args);
	}

}
