package com.gl.aopsample.springsecurityaop.service;

import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl {

	public void getCustomerFeedback()
	{
		System.out.println("Customer feedback is good");
	}
}
